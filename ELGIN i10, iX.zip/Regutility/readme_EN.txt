RegUtility - Modify printer driver parameters

Copyright 2014 SNBC
================================


1.  RegUtility function
--------------------------------

RegUtility is used for modifying printer driver default parameters expediently.



2.  When and how to use the RegUtility
-----------------------------------------


1) Install the printer dirver.
2) Modify the default parameters on the computer.\
3) Config the file config.ini: add printer dirver name after "DriverConfig=",for example :DriverConfig=BTP-R880NP(P).
4) Run RegUtility.exe in RegUtility folder.
5) Click [OK], output "Regbak.dat"file,generate a new printer driver installer.
6) Run Setup.exe in the folder. The printer driver default parameters have been modified while installing the printer dirver .



3.    History
-------------------
      
  - V1.02
	Release date: 7/30/2014(MM/DD/YYYY)
	Changes:      First release.

